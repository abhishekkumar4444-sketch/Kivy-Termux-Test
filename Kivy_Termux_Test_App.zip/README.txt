Kivy + Termux local test app

This app sends only one fixed test message when the user taps the button.
It does not collect contacts, location, files, messages, or other device data.

Destination: http://127.0.0.1:8765/test

Run the Termux server on the SAME Android phone before pressing the app button.
127.0.0.1 is loopback, not a public IP. This HTTP setup is for local testing only.

Files: main.py and buildozer.spec.
Upload this ZIP to the GitHub repository root. Create the workflow separately at
.github/workflows/build.yml using GitHub's web interface.
