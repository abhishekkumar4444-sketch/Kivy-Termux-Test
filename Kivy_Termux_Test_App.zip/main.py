import json
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.network.urlrequest import UrlRequest

SERVER_URL = "http://127.0.0.1:8765/test"

class TestApp(App):
    def build(self):
        layout = BoxLayout(orientation="vertical", padding=24, spacing=18)
        layout.add_widget(Label(text="Kivy + Termux Test", font_size="24sp"))
        self.status = Label(text="Ready. Press the button to send a test message.", font_size="17sp")
        layout.add_widget(self.status)
        button = Button(text="Send Test Message", font_size="20sp", size_hint_y=0.3)
        button.bind(on_press=self.send_test)
        layout.add_widget(button)
        return layout

    def send_test(self, instance):
        self.status.text = "Sending test message..."
        payload = json.dumps({"message": "Hello from my Kivy Android app"})
        try:
            UrlRequest(
                SERVER_URL,
                req_body=payload,
                req_headers={"Content-Type": "application/json"},
                method="POST",
                timeout=10,
                on_success=self.on_success,
                on_error=self.on_error,
                on_failure=self.on_failure
            )
        except Exception as exc:
            self.status.text = "Request error: " + str(exc)

    def on_success(self, request, result):
        self.status.text = "Success: Termux received the test message."

    def on_error(self, request, error):
        self.status.text = "Connection error: " + str(error)

    def on_failure(self, request, result):
        self.status.text = "Server response was unsuccessful."

if __name__ == "__main__":
    TestApp().run()
